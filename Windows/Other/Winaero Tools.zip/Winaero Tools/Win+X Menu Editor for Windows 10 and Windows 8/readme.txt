Win+X Menu Editor
Created by Sergey "Happy Bulldozer" Tkachenko
http://winaero.com
The change log is available at the download page

This software uses the hashlnk tool source code
hashlnk was created by Rafael Rivera
http://www.withinwindows.com/