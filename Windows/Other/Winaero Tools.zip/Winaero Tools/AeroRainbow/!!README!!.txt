Hello,

This is the readme file for AeroRainbow. Here are some things you need to know.

****************
1. Installation
****************
You have to place AeroRainbow to a writable location. It will create and use a special AeroRainbow.ini file to store your preferences.
I have removed the installer and and made the app portable.

****************
2. Binaries
****************
Since version 2.7 there are two folders with executable files in the archive. 
The first one works like a Windows 7 "native" application (no additional components required, i.e. .NET Framework).
The second one acts as a Windows 8/Windows 10 "native" software, for the same reason. 

They are absolutely indentical, just compiled with different versions of .NET.

****************
3. Command line and tricks
****************
There are two command line switches available:
aerorainbow /close - closes the currently running instance of Aerorainbow. Useful when you have disabled the tray icon in preferences.
aerorainbow /config - opens the settings window. Also useful without tray icon.

Feel free to leave your feedback on my web site,
http://winaero.com

Best regards, 
Sergey Tkachenko
