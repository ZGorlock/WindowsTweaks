Pin to 8
The universal pinning tool for Windows 8 and Windows 8.1
Allows you to pin almost everything to Start Screen or Taskbar
Created by Sergey Tkachenko.
http://winaero.com

***************************************
Those awesome icons by http://dakirby309.deviantart.com