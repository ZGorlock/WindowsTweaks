How to Remove the Default Account Picture in Windows 10
This photo is needed
See https://www.majorgeeks.com/content/page/how_to_remove_the_default_windows_10_sign_in_screen_picture.html for more